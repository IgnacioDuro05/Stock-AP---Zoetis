from fastapi import FastAPI, HTTPException, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import HTMLResponse, FileResponse
from pydantic import BaseModel
from typing import Optional
import sqlite3, os, datetime

app = FastAPI()
DB = "stock.db"

# ── Init DB ──────────────────────────────────────────────
def get_db():
    conn = sqlite3.connect(DB)
    conn.row_factory = sqlite3.Row
    return conn

def init_db():
    conn = get_db()
    c = conn.cursor()
    c.execute("""CREATE TABLE IF NOT EXISTS productos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        nombre TEXT NOT NULL,
        stock INTEGER DEFAULT 0,
        minimo INTEGER DEFAULT 0,
        unidad TEXT DEFAULT 'EA',
        proveedor TEXT DEFAULT ''
    )""")
    c.execute("""CREATE TABLE IF NOT EXISTS movimientos (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fecha TEXT,
        hora TEXT,
        producto_id INTEGER,
        producto_nombre TEXT,
        tipo TEXT,
        cantidad INTEGER,
        lote TEXT,
        vto TEXT,
        proveedor TEXT,
        obs TEXT,
        usuario TEXT
    )""")
    # Productos de ejemplo si la tabla está vacía
    c.execute("SELECT COUNT(*) FROM productos")
    if c.fetchone()[0] == 0:
        c.executemany("INSERT INTO productos (nombre,stock,minimo,unidad,proveedor) VALUES (?,?,?,?,?)", [
            ('Bolsas Térmicas', 5, 10, 'AU', 'A+P Argentina SA'),
            ('Geles Refrigerantes', 45, 20, 'EA', 'A+P Argentina SA'),
            ('Cajas de Transporte', 80, 15, 'EA', 'Proveedor B'),
        ])
    conn.commit()
    conn.close()

init_db()

# ── Models ───────────────────────────────────────────────
class ProductoCreate(BaseModel):
    nombre: str
    stock: int = 0
    minimo: int = 0
    unidad: str = 'EA'
    proveedor: str = ''

class MovimientoCreate(BaseModel):
    tipo: str
    producto_id: int
    cantidad: int
    lote: Optional[str] = ''
    vto: Optional[str] = ''
    proveedor: Optional[str] = ''
    obs: Optional[str] = ''
    usuario: str = 'Depósito'

# ── Endpoints ────────────────────────────────────────────
@app.get("/api/productos")
def get_productos():
    conn = get_db()
    rows = conn.execute("SELECT * FROM productos ORDER BY nombre").fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.post("/api/productos")
def crear_producto(p: ProductoCreate):
    conn = get_db()
    conn.execute("INSERT INTO productos (nombre,stock,minimo,unidad,proveedor) VALUES (?,?,?,?,?)",
                 (p.nombre, p.stock, p.minimo, p.unidad, p.proveedor))
    conn.commit()
    conn.close()
    return {"ok": True}

@app.delete("/api/productos/{pid}")
def eliminar_producto(pid: int):
    conn = get_db()
    conn.execute("DELETE FROM productos WHERE id=?", (pid,))
    conn.commit()
    conn.close()
    return {"ok": True}

@app.post("/api/movimientos")
def registrar_movimiento(m: MovimientoCreate):
    conn = get_db()
    prod = conn.execute("SELECT * FROM productos WHERE id=?", (m.producto_id,)).fetchone()
    if not prod:
        raise HTTPException(404, "Producto no encontrado")
    if m.tipo == 'egreso' and prod['stock'] < m.cantidad:
        raise HTTPException(400, f"Stock insuficiente: solo hay {prod['stock']} {prod['unidad']}")
    delta = m.cantidad if m.tipo == 'ingreso' else -m.cantidad
    conn.execute("UPDATE productos SET stock=stock+? WHERE id=?", (delta, m.producto_id))
    now = datetime.datetime.now()
    conn.execute("""INSERT INTO movimientos
        (fecha,hora,producto_id,producto_nombre,tipo,cantidad,lote,vto,proveedor,obs,usuario)
        VALUES (?,?,?,?,?,?,?,?,?,?,?)""",
        (now.strftime('%Y-%m-%d'), now.strftime('%H:%M'), m.producto_id,
         prod['nombre'], m.tipo, m.cantidad, m.lote, m.vto, m.proveedor, m.obs, m.usuario))
    conn.commit()
    conn.close()
    return {"ok": True}

@app.get("/api/movimientos")
def get_movimientos(tipo: str = '', q: str = ''):
    conn = get_db()
    sql = "SELECT * FROM movimientos WHERE 1=1"
    params = []
    if tipo:
        sql += " AND tipo=?"; params.append(tipo)
    if q:
        sql += " AND (producto_nombre LIKE ? OR lote LIKE ?)"; params += [f'%{q}%', f'%{q}%']
    sql += " ORDER BY id DESC"
    rows = conn.execute(sql, params).fetchall()
    conn.close()
    return [dict(r) for r in rows]

@app.get("/", response_class=HTMLResponse)
def root():
    return FileResponse("static/index.html")

app.mount("/", StaticFiles(directory="static"), name="static")
